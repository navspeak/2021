#!/bin/bash

docker run -d --cap-add SYS_PTRACE --security-opt seccomp:unconfined --name no-throttle -it ajtd-ubuntu:latest

docker exec -it no-throttle /bin/bash
