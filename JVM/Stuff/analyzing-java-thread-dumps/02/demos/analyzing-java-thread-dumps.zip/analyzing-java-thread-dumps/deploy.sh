#!/bin/bash

# first, build
mvn clean install

# Copy .jar files to assets directory
cp ./target/*.jar ./docker/assets/

# and bake into a docker image 
docker build -t ajtd-ubuntu:1.0 ./docker

