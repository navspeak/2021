package com.uriahl.ajtd.connectionpool;

/**
 * @author Uriah Levy, Pluralsight
 * @since 08/09/2017.
 */
class Constants {

    static final int NUM_OF_EXECUTORS = 3;
    final static String PROTECTED_RESOURCE_URL = "https://index.docker.io/v2/";
}
