package com.uriahl.ajtd.threadstates;

/**
 * @author Uriah Levy, Pluralsight
 * @since 28/10/2017.
 */
public class BlockedState {
    public static void main(String[] args) {
        Foo object = new Foo();
        // Create 2 threads
        ThreadB firstThread = new ThreadB(object);
        ThreadB secondThread = new ThreadB(object);
        // Start them
        firstThread.start();
        secondThread.start();
    }
}

class ThreadB extends Thread {

    private Foo object;

    ThreadB(Foo object) {
        this.object = object;
    }

    @Override
    public void run() {
        object.someSynchronizedMethod();
    }
}