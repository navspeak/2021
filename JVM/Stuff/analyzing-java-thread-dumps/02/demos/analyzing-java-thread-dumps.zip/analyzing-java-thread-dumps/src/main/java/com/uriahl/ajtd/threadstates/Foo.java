package com.uriahl.ajtd.threadstates;

class Foo {
    synchronized void someSynchronizedMethod() {
        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}