package com.uriahl.ajtd.threadstates;

/**
 * @author Uriah Levy, Pluralsight
 * @since 28/10/2017.
 */
public class WaitingStates {
    public static void main(String[] args) {
        ThreadA someThread = new ThreadA();
        someThread.start();

        try {
            synchronized (someThread) {
                someThread.wait();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class ThreadA extends Thread {
    @Override
    public void run() {
        synchronized (this) {
            try {
                // Sleep 30, then notify whoever is waiting
                sleep(30000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            notify();
        }
    }
}
