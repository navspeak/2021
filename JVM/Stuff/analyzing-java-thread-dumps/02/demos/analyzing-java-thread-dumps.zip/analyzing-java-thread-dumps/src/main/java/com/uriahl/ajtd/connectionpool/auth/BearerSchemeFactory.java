package com.uriahl.ajtd.connectionpool.auth;

import org.apache.http.auth.AuthScheme;
import org.apache.http.auth.AuthSchemeProvider;
import org.apache.http.protocol.HttpContext;

/**
 * @author Uriah Levy, Pluralsight
 * @since 25/08/2017.
 */
public class BearerSchemeFactory implements AuthSchemeProvider {

    @Override
    public AuthScheme create(HttpContext context) {
        return new BearerScheme();
    }
}
