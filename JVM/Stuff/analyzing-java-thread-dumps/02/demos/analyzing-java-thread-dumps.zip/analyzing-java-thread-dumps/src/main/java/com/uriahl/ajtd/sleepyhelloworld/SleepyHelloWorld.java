package com.uriahl.ajtd.sleepyhelloworld;

/**
 * @author Uriah Levy, Pluralsight
 * @since 25/11/2017.
 */
public class SleepyHelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, world!\nZzZ..");
        // Keep the main thread running for a while longer
        sleep();
    }

    private static void sleep() {
        try {
            Thread.sleep(600000); // 10 minutes
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
